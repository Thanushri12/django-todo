from django.shortcuts import render, redirect
from .models import Task

def index(request):
    if request.method == 'POST':
        title = request.POST.get('task')
        if title:  # prevent empty tasks
            Task.objects.create(title=title, complete=False)
        return redirect('index')  # avoid resubmission on refresh

    tasks = Task.objects.all()
    return render(request, 'index.html', {'tasks': tasks})
